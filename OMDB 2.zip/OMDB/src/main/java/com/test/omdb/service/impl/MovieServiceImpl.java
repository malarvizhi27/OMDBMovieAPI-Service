package com.test.omdb.service.impl;


import com.test.omdb.config.dto.MovieResponseDto;
import com.test.omdb.domain.Movie;
import com.test.omdb.domain.MovieOMDB;
import com.test.omdb.exception.MovieNotFoundException;
import com.test.omdb.repo.MovieRepository;
import com.test.omdb.service.MovieService;
import com.test.omdb.service.OMDBApiService;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * This class is an implementation of Movie Service
 *
 */
@Log
@Service
public class MovieServiceImpl implements MovieService{

    private MovieRepository movieRepository;

    private OMDBApiService omdbApiService;

    @Autowired
    public MovieServiceImpl(MovieRepository movieRepository, OMDBApiService omdbApiService) {
        this.movieRepository = movieRepository;
        this.omdbApiService = omdbApiService;
    }

    /**
     * This is the Method to get movie details from csv and omdb API and return if it won oscar
     *
     * @param movieTitle
     * @return MovieResponseDto
     */
    @Override
    public MovieResponseDto hasMovieWonOscar(String movieTitle) {

        Movie movie = getMovieByOscarWonAndTitleFromCSV(movieTitle);
        MovieOMDB movieOMDB = getMovieByOscarWonAndTitle(movieTitle);
        MovieResponseDto movieResponseDto = MovieResponseDto.builder()
                .movie(movie)
                .movieOMDB(movieOMDB)
                .hasWonOscar(movie != null || movieOMDB != null)
                .build();
        return movieResponseDto;
    }

    /**
     * This is the Method to check the movie details from CSV and return if movie won oscar
     *
     * @param movieTitle
     * @return - movie
     */
    Movie getMovieByOscarWonAndTitleFromCSV(String movieTitle) {
        log.info("getMovieByOscarWonAndTitle From CSV called for movie " + movieTitle);
        if (movieTitle.isBlank()||movieTitle.isEmpty()){
            throw new MovieNotFoundException();
        }
        List<Movie> movies = movieRepository.findByCategoryAndWonAndNomineeEquals(movieTitle, "Best Picture", "YES");
        return movies.size() > 0 ? movies.get(0) : null;
    }

    /**
     * This is the Method to search in omdb API and return if movie won oscar
     *
     * @param movieTitle
     * @return - movieOMDB
     */
    MovieOMDB getMovieByOscarWonAndTitle(String movieTitle) {
        log.info("getMovieByOscarWonAndTitle from OMDB called for movie " + movieTitle);
       /* if (movieTitle.isBlank()||movieTitle.isEmpty()){
            throw new MovieNotFoundException();
        }*/
        return omdbApiService.isMovieOscarWinning(movieTitle);
    }
}
