package com.test.omdb.config.dto;

import com.test.omdb.domain.Movie;
import com.test.omdb.domain.MovieOMDB;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Component
public class MovieResponseDto {
    Movie movie;
    MovieOMDB movieOMDB;
    boolean hasWonOscar;
    String error;
    String status;
    String statusCode;
}
