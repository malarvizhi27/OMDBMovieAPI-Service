package com.test.omdb.service.impl;

import com.test.omdb.exception.MovieNotFoundException;
import com.test.omdb.service.OMDBApiService;
import com.test.omdb.domain.MovieOMDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


/**
 * This class is an implementation of OMDB API Service
 *
 */
import java.util.Collections;
@Service
public class OMDBApiServiceImpl implements OMDBApiService {
    @Value("${omdb.api.url}")
    private String omdbApiUrl;

    @Value("${omdb.api.key}")
    private String omdbApiKey;

    private RestTemplate restTemplate;

    @Autowired
    public OMDBApiServiceImpl(final RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /**
     * This is the Method to get movie details from omdb API . It will be queried by RestTemplate using omdb API key
     *
     * @param movieTitle
     * @return MovieOMDB
     */
    @Override
    public MovieOMDB isMovieOscarWinning(String movieTitle) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        HttpEntity<String> httpEntity = new HttpEntity<>(headers);
       /* if(movieTitle.isEmpty()|| movieTitle.isBlank()){
            throw new MovieNotFoundException();
        }*/
        String urlCompBuilder =
                UriComponentsBuilder.fromHttpUrl(omdbApiUrl)
                        .queryParam("t", movieTitle)
                        .queryParam("type", "movie")
                        .queryParam("apiKey", omdbApiKey)
                        .queryParam("page", "1")
                        .buildAndExpand()
                        .toString();

        ResponseEntity<MovieOMDB> movieOMDBResponseEntity = restTemplate.exchange(urlCompBuilder, HttpMethod.GET, httpEntity, MovieOMDB.class);
        MovieOMDB movieOMDB = movieOMDBResponseEntity.getBody();
        return isOscarWon(movieOMDB) ? movieOMDB : null;
    }

    private boolean isOscarWon(MovieOMDB movieOMDB) {
        String awards = movieOMDB.getAwards();
        return awards != null & awards.contains("Won") && (awards.contains("Oscar") || awards.contains("Oscars"));
    }
}
