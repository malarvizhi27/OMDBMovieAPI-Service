package com.test.omdb.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.test.omdb.config.dto.MovieResponseDto;

/**
 *
 * This Interface contains method for Movie Service
 *
 */
public interface MovieService {

    MovieResponseDto hasMovieWonOscar(String movieTitle) throws JsonProcessingException;
}
