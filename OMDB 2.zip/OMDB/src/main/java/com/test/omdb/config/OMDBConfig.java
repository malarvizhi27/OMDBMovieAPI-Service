package com.test.omdb.config;

import com.test.omdb.domain.Movie;
import com.test.omdb.repo.MovieRepository;
import com.test.omdb.util.CSVParserHelper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.web.client.RestTemplate;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Configuration
public class OMDBConfig {
        CSVParserHelper csvParserHelper = new CSVParserHelper();
        @Bean
        RestTemplate getRestTemplate() {
            return new RestTemplate();
        }

        @Bean
        CommandLineRunner initDatabase(MovieRepository movieRepository) {

            return args -> {
                List<Movie> movies = csvParserHelper.parseCSVFile("academy_awards.csv");
                movies.forEach(movie -> movieRepository.save(movie));
            };
        }
    }

