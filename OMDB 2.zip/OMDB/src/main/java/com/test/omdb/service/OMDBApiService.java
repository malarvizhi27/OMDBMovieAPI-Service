package com.test.omdb.service;

import com.test.omdb.domain.MovieOMDB;

/**
 *
 * This Interface contains method for OMDB API Service
 *
 */
public interface OMDBApiService {
    MovieOMDB isMovieOscarWinning(String movieTitle);

}
