package com.test.omdb.util;

import com.test.omdb.domain.Movie;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
public class CSVParserHelper {

    public List<Movie> parseCSVFile(String csvFleName) throws Exception {
        Resource resource = (Resource) new ClassPathResource(csvFleName);
        File file = resource.getFile();
        final List<Movie> movies = new ArrayList<>();
        try {
            try (final BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    final String[] data = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)",-1);
                    final Movie movie = new Movie();
                    movie.setYear(data[0]);
                    movie.setCategory(data[1]);
                    movie.setNominee(data[2]);
                    movie.setAdditionalInfo(data[3].split("\\{")[0].trim());
                    movie.setWon(data[4]);
                    movies.add(movie);
                }
                return movies;
            }
        } catch (final IOException e) {
            throw new Exception("Failed to parse CSV file {}", e);
        }
    }

}
