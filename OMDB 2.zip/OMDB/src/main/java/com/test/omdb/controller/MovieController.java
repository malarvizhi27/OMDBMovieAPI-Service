package com.test.omdb.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.test.omdb.config.dto.MovieResponseDto;
import com.test.omdb.service.MovieService;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Movie application
 * This Class provides REST End point to handle web requests
 *
 */
@Log
@RestController
@RequestMapping("/rest/movies/v1")
public class MovieController {
    private final MovieService movieService;

    @Autowired
    public MovieController(final MovieService movieService) {
        this.movieService = movieService;
    }
    /**
     * Rest End Point to identify if the given movie won oscar or not
     * @param movieTitle
     * @return ResponseEntity
     */
    @GetMapping("/hasMovieWonOscar/{movieTitle}")
    public ResponseEntity<MovieResponseDto> hasMovieWonOscar(@PathVariable String movieTitle) throws JsonProcessingException {
        log.info("Checking for movie " + movieTitle + " has won Oscar");
        MovieResponseDto movieResponseDtoResponseEntity = movieService.hasMovieWonOscar(movieTitle);
        return ResponseEntity.ok(movieResponseDtoResponseEntity);
    }

}
