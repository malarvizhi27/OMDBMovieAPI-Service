package com.test.omdb.repo;

import com.test.omdb.domain.Movie;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Integer> {

        List<Movie> findByCategoryAndWonAndNomineeEquals(String category, String won, String additionalInfo);

}