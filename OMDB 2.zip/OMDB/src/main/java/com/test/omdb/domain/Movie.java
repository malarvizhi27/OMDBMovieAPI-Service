package com.test.omdb.domain;

import jakarta.persistence.*;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Movie {
    private String year;
    private String category;
    @Column(length = 4000)
    private String nominee;
    @Column(length = 4000)
    private String additionalInfo;
    @Column(length = 400)
    private String won;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
}
