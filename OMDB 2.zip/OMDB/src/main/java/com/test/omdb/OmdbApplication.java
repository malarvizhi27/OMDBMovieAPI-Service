package com.test.omdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmdbApplication.class, args);
	}

}
