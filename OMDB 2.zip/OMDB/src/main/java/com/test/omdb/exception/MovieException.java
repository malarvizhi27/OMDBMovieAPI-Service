package com.test.omdb.exception;

public class MovieException extends RuntimeException{
    public MovieException() {
    }

    public MovieException(String message) {
        super(message);
    }

}
