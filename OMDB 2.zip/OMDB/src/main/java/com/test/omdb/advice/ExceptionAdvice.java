package com.test.omdb.advice;

import com.test.omdb.exception.ExceptionMessage;
import com.test.omdb.exception.MovieException;
import com.test.omdb.exception.MovieNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Date;

/**
 *Global Exception handler for All Exception
 * AOP for All Layers Exception
 */

@RestControllerAdvice
public class ExceptionAdvice {

    private static final Logger logger = LoggerFactory.getLogger(ExceptionAdvice.class);

    //@Value(value = "${data.exception.notFoundMessage}")
    private String notFoundMessage = "Movie Not available with this Title";


    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = {MovieNotFoundException.class})
    public ResponseEntity<ExceptionMessage> handleMovieNotFoundException(MovieNotFoundException mnex) {
        logger.error("Movie Not found Exception: ", mnex.getMessage());

        ExceptionMessage message = new ExceptionMessage(
                HttpStatus.NOT_FOUND.value(),
                new Date(),
                mnex.getClass().getSimpleName().concat(" : ").concat(notFoundMessage),
                mnex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
    }

    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = {Exception.class, MovieException.class})
    public ResponseEntity<ExceptionMessage> handleGlobalException(Exception ex) {
        logger.error("Unknown Exception: ", ex.getMessage());
        ExceptionMessage message = new ExceptionMessage(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                new Date(),
                "Unknown Exception",
                ex.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(message);
    }
}
