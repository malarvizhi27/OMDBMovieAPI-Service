package com.test.omdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
