package com.test.omdb.service.impl;

import com.test.omdb.domain.MovieOMDB;
import com.test.omdb.service.OMDBApiService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.RestTemplate;
import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest
public class OMDBApiServiceImplTest {

    //private RestTemplate restTemplate;
    OMDBApiService omdbApiService ;//= new OMDBApiServiceImpl();
    @Test
    public void givenMovieNotNull_whenCheckingMovieWonOscar(String movieTitle) {
        movieTitle = "BlackSwan";
        MovieOMDB movieOMDB = new MovieOMDB("20", "BlackSwan", "2010", "R", "17 Dec 2010", "108 min", "Drama, Thriller",
                "Darren Aronofsky", "Mark Heyman, Andres Heinz, John J. McLauglin", "United State", "Won 1 Oscar",
                "https://m.media-amazon.com/images/", "8.0/10", "768", null, "N/A", "79", "8.0", "768,707", "tt0947798",
                "movie", "True", "29 Mar 2011", "$106,954,678", "N/A", "N/A");
        assertEquals(movieOMDB,omdbApiService.isMovieOscarWinning(movieTitle));
    }
    }
