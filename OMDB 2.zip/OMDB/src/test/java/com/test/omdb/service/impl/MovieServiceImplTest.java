package com.test.omdb.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.test.omdb.service.MovieService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class MovieServiceImplTest {

    MovieService movieService;
    @Test
    public void givenMovieNotNull_whenCheckingHasMovieWonOscar_throwsException()  {
        String movieTitle = "Gladiator";
        assertThrows(NullPointerException.class, ()->movieService.hasMovieWonOscar(movieTitle));

    }


}