### Solution
* Insert csv data to H2 DB( academy_awards.csv is injected in h2 DB on load via OMDBConfig)
* CSVParserHelper (CSVParserHelper is written to parse data from csv and load to H2 DB)
* To call OMDB API(Rest Template is created and OMDB API is called with API key 806dc18e)
* http request to check movie won oscar(If httprequeest trigger with Movie Title, MovieService will validate both csv and OMDB API and return JSON value of the particular movie if it won Oscar for Best Picture else it will return Null )

### Guides
* [Accessing Data from OMDB API](https://www.omdbapi.com/?apikey=806dc18e&getdetails&&t=Auntie%20Mame)
* [Calling a RESTful Web Service call ](http://localhost:8080/rest/movies/v1/hasMovieWonOscar/Black%20Swan)