# Getting Started

### Reference Documentation
* OMDB is online movie database containing info about a movie like movie title,runningtime,budget,imdb ratings etc.
* Data from CSV is having basic info of the movie like movie category , nominee for the award,additional Info etc.
*  rest/movies/v1/hasMovieWonOscar/ will search both OMDB API and csv data from DB with movietitle and return result if any of them returning data about the movie oscar win
   Footer
   © 2023 GitHub, Inc.
   Footer navigation
   Terms
