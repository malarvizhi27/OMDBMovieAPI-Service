### Reference Documentation
* Make Asynchronus calls
* Application cache — it can be done with spring cache @EnableCaching
* Divide projects into modules