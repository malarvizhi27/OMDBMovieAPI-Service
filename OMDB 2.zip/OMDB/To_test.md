#  Getting Started

### Running the application
* Run OmdbApplication(run the application using the maven command mvn spring-boot:run )
* Server run(Server will start on port number 8080)
* Enter this url and check h2 DB loaded [check h2 DB](http://localhost:8080/h2-console)
* data source for h2 DB jdbc:h2:mem:moviedb and username is movie and password is movie
* Enter this url from browser [url](http://localhost:8080/rest/movies/v1/hasMovieWonOscar/Black%20Swan)
* JSON Response JSON Response with the details of the movie will be displayed if the movie has won oscar award
* hasWonOscar in the JSON Response will provide True/False to identify it won Oscar in the MovieResponseDto
* Sample JSON Response is below

```json
{
    "movie":,
    "movieOMDB": {
      },
    "hasWonOscar": 
    "error": 
    "status": 
    "statusCode": 
}
```