### Reference Documentation
* RestEndpoint to be created to get ratings of the movie
* RestEndpoint to be created to get Top 10 movies bases on Box office value