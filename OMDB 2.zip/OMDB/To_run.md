# Getting Started

### Reference Documentation
* To check this REST endpoint rest/movies/v1/hasMovieWonOscar/ Enter this  url from browser [url](http://localhost:8080/rest/movies/v1/hasMovieWonOscar/Black%20Swan)
* MovieResponseDTO will be returned with the field hasWonOscar as true if the movie won Oscar

```json
{
    "movie":,
    "movieOMDB": {
      },
    "hasWonOscar": 
    "error": 
    "status": 
    "statusCode": 
}
```
* Enter this url from browser to validate Rest API response is correct [OMDB API Url](https://www.omdbapi.com/?apikey=806dc18e&getdetails&&t=Black%20Swan)